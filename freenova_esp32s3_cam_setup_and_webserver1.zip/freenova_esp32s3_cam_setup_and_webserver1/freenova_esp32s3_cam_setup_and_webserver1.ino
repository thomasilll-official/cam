
#include "esp_camera.h"
#include <WiFi.h>
#include <WebServer.h>
#include "FS.h"
#include "SD_MMC.h"
#include <vector>

// =================================================
// FREENOVE ESP32-S3 WROOM CAMERA PINS
// =================================================

#define PWDN_GPIO_NUM     -1
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM     15

#define SIOD_GPIO_NUM      4
#define SIOC_GPIO_NUM      5

#define Y9_GPIO_NUM       16
#define Y8_GPIO_NUM       17
#define Y7_GPIO_NUM       18
#define Y6_GPIO_NUM       12
#define Y5_GPIO_NUM       10
#define Y4_GPIO_NUM        8
#define Y3_GPIO_NUM        9
#define Y2_GPIO_NUM       11

#define VSYNC_GPIO_NUM     6
#define HREF_GPIO_NUM      7
#define PCLK_GPIO_NUM     13

// =================================================
// SD CARD PINS - FREENOVE
// =================================================

#define SD_MMC_CMD 38
#define SD_MMC_CLK 39
#define SD_MMC_D0  40

// =================================================
// WIFI SETTINGS
// =================================================

const char* AP_SSID = "ESP32-CAMERA";
const char* AP_PASSWORD = "12345678";

const char* WIFI_SSID = "Airtel_Savira airtel";
const char* WIFI_PASSWORD = "Vaishali198@";

// =================================================
// GLOBAL VARIABLES
// =================================================

WebServer server(80);

bool cameraReady = false;
bool sdReady = false;
bool recording = false;

File videoFile;

uint32_t frameCount = 0;
uint32_t videoStartTime = 0;

const uint32_t VIDEO_FPS = 10;
const uint32_t MAX_VIDEO_FRAMES = 5000;

String currentVideoPath = "";

struct AviIndexEntry {
  uint32_t offset;
  uint32_t size;
};

std::vector<AviIndexEntry> aviIndex;

uint32_t riffSizePos;
uint32_t moviSizePos;
uint32_t moviDataStart;
uint32_t avihFramesPos;
uint32_t strhFramesPos;

// =================================================
// AVI FILE HELPERS
// =================================================

void writeFourCC(File &f, const char *s) {
  f.write((const uint8_t*)s, 4);
}

void writeU16(File &f, uint16_t v) {
  uint8_t b[2] = {
    (uint8_t)(v & 0xFF),
    (uint8_t)(v >> 8)
  };
  f.write(b, 2);
}

void writeU32(File &f, uint32_t v) {
  uint8_t b[4] = {
    (uint8_t)(v & 0xFF),
    (uint8_t)(v >> 8),
    (uint8_t)(v >> 16),
    (uint8_t)(v >> 24)
  };
  f.write(b, 4);
}

void patchU32(File &f, uint32_t pos, uint32_t value) {
  uint32_t oldPos = f.position();
  f.seek(pos);
  writeU32(f, value);
  f.seek(oldPos);
}

// =================================================
// CREATE AVI HEADER
// =================================================

void writeAviHeader(uint16_t width, uint16_t height) {

  // RIFF HEADER

  writeFourCC(videoFile, "RIFF");

  riffSizePos = videoFile.position();
  writeU32(videoFile, 0);

  writeFourCC(videoFile, "AVI ");

  // HEADER LIST

  writeFourCC(videoFile, "LIST");

  uint32_t hdrlSizePos = videoFile.position();
  writeU32(videoFile, 0);

  writeFourCC(videoFile, "hdrl");

  // MAIN AVI HEADER

  writeFourCC(videoFile, "avih");
  writeU32(videoFile, 56);

  writeU32(videoFile, 1000000 / VIDEO_FPS);
  writeU32(videoFile, 1000000);
  writeU32(videoFile, 0);
  writeU32(videoFile, 0x10);

  avihFramesPos = videoFile.position();
  writeU32(videoFile, 0);

  writeU32(videoFile, 0);
  writeU32(videoFile, 1);
  writeU32(videoFile, width * height * 2);
  writeU32(videoFile, width);
  writeU32(videoFile, height);

  for (int i = 0; i < 4; i++) {
    writeU32(videoFile, 0);
  }

  // STREAM LIST

  writeFourCC(videoFile, "LIST");

  uint32_t strlSizePos = videoFile.position();
  writeU32(videoFile, 0);

  writeFourCC(videoFile, "strl");

  // STREAM HEADER

  writeFourCC(videoFile, "strh");
  writeU32(videoFile, 56);

  writeFourCC(videoFile, "vids");
  writeFourCC(videoFile, "MJPG");

  writeU32(videoFile, 0);
  writeU16(videoFile, 0);
  writeU16(videoFile, 0);

  writeU32(videoFile, 0);
  writeU32(videoFile, 1);
  writeU32(videoFile, VIDEO_FPS);
  writeU32(videoFile, 0);

  strhFramesPos = videoFile.position();
  writeU32(videoFile, 0);

  writeU32(videoFile, width * height * 2);
  writeU32(videoFile, 0xFFFFFFFF);
  writeU32(videoFile, 0);

  writeU16(videoFile, 0);
  writeU16(videoFile, 0);
  writeU16(videoFile, width);
  writeU16(videoFile, height);

  // BITMAP INFO HEADER

  writeFourCC(videoFile, "strf");
  writeU32(videoFile, 40);

  writeU32(videoFile, 40);
  writeU32(videoFile, width);
  writeU32(videoFile, height);

  writeU16(videoFile, 1);
  writeU16(videoFile, 24);

  writeFourCC(videoFile, "MJPG");

  writeU32(videoFile, width * height * 3);
  writeU32(videoFile, 0);
  writeU32(videoFile, 0);
  writeU32(videoFile, 0);
  writeU32(videoFile, 0);

  // PATCH LIST SIZES

  uint32_t headerEnd = videoFile.position();

  patchU32(
    videoFile,
    strlSizePos,
    headerEnd - (strlSizePos + 4)
  );

  patchU32(
    videoFile,
    hdrlSizePos,
    headerEnd - (hdrlSizePos + 4)
  );

  // MOVIE LIST

  writeFourCC(videoFile, "LIST");

  moviSizePos = videoFile.position();
  writeU32(videoFile, 0);

  writeFourCC(videoFile, "movi");

  moviDataStart = videoFile.position();

  videoFile.flush();
}

// =================================================
// WRITE VIDEO FRAME
// =================================================

bool writeAviFrame(camera_fb_t *fb) {

  if (!videoFile || !fb) {
    return false;
  }

  if (aviIndex.size() >= MAX_VIDEO_FRAMES) {
    stopRecording();
    return false;
  }

  uint32_t chunkPosition = videoFile.position();

  writeFourCC(videoFile, "00dc");
  writeU32(videoFile, fb->len);

  size_t written = videoFile.write(fb->buf, fb->len);

  if (written != fb->len) {
    Serial.println("SD write error!");
    stopRecording();
    return false;
  }

  if (fb->len & 1) {
    videoFile.write((uint8_t)0);
  }

  AviIndexEntry entry;

  entry.offset = chunkPosition - moviDataStart;
  entry.size = fb->len;

  aviIndex.push_back(entry);

  frameCount++;

  return true;
}

// =================================================
// FINALIZE AVI VIDEO
// =================================================

void stopRecording() {

  if (!recording) {
    return;
  }

  recording = false;

  Serial.println("Stopping video recording...");

  if (videoFile) {

    uint32_t moviEnd = videoFile.position();

    patchU32(
      videoFile,
      moviSizePos,
      moviEnd - (moviSizePos + 4)
    );

    // INDEX CHUNK

    writeFourCC(videoFile, "idx1");

    writeU32(videoFile, aviIndex.size() * 16);

    for (size_t i = 0; i < aviIndex.size(); i++) {

      writeFourCC(videoFile, "00dc");

      writeU32(videoFile, 0x10);
      writeU32(videoFile, aviIndex[i].offset);
      writeU32(videoFile, aviIndex[i].size);
    }

    uint32_t finalSize = videoFile.position();

    // UPDATE FRAME COUNTS

    patchU32(videoFile, avihFramesPos, frameCount);
    patchU32(videoFile, strhFramesPos, frameCount);

    // UPDATE RIFF SIZE

    patchU32(
      videoFile,
      riffSizePos,
      finalSize - 8
    );

    videoFile.flush();
    videoFile.close();

    Serial.print("Video saved: ");
    Serial.println(currentVideoPath);

    Serial.print("Frames: ");
    Serial.println(frameCount);
  }

  aviIndex.clear();

  Serial.println("Recording stopped.");
}

// =================================================
// START VIDEO RECORDING
// =================================================

bool startRecording() {

  if (!sdReady || !cameraReady || recording) {
    return false;
  }

  camera_fb_t *fb = esp_camera_fb_get();

  if (!fb) {
    return false;
  }

  currentVideoPath =
    "/videos/VIDEO_" + String(millis()) + ".avi";

  videoFile = SD_MMC.open(currentVideoPath, FILE_WRITE);

  if (!videoFile) {

    esp_camera_fb_return(fb);

    Serial.println("Cannot create video file!");
    return false;
  }

  frameCount = 0;
  aviIndex.clear();

  aviIndex.reserve(MAX_VIDEO_FRAMES);

  writeAviHeader(fb->width, fb->height);

  recording = true;
  videoStartTime = millis();

  bool ok = writeAviFrame(fb);

  esp_camera_fb_return(fb);

  if (!ok) {
    stopRecording();
    return false;
  }

  Serial.println("VIDEO RECORDING STARTED!");

  return true;
}

// =================================================
// PHOTO CAPTURE
// =================================================

void handlePhoto() {

  if (!cameraReady || !sdReady) {
    server.send(500, "text/plain", "Camera or SD unavailable");
    return;
  }

  if (recording) {
    server.send(409, "text/plain", "Stop recording before taking a photo");
    return;
  }

  camera_fb_t *fb = esp_camera_fb_get();

  if (!fb) {
    server.send(500, "text/plain", "Camera capture failed");
    return;
  }

  String path =
    "/photos/PHOTO_" + String(millis()) + ".jpg";

  File file = SD_MMC.open(path, FILE_WRITE);

  if (!file) {

    esp_camera_fb_return(fb);

    server.send(500, "text/plain", "Cannot save photo");
    return;
  }

  size_t written = file.write(fb->buf, fb->len);

  file.close();

  esp_camera_fb_return(fb);

  if (written == 0) {
    server.send(500, "text/plain", "Photo save failed");
    return;
  }

  Serial.print("PHOTO SAVED: ");
  Serial.println(path);

  server.send(200, "text/plain", "Photo saved: " + path);
}

// =================================================
// LIVE PREVIEW
// =================================================

void handlePreview() {

  if (!cameraReady) {
    server.send(503, "text/plain", "Camera unavailable");
    return;
  }

  camera_fb_t *fb = esp_camera_fb_get();

  if (!fb) {
    server.send(500, "text/plain", "Capture failed");
    return;
  }

  server.setContentLength(fb->len);
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "image/jpeg", "");

  server.sendContent(
    (const char*)fb->buf,
    fb->len
  );

  esp_camera_fb_return(fb);
}

// =================================================
// START / STOP RECORDING ROUTES
// =================================================

void handleRecordStart() {

  if (recording) {
    server.send(200, "text/plain", "Already recording");
    return;
  }

  if (startRecording()) {
    server.send(200, "text/plain", "Recording started");
  } else {
    server.send(500, "text/plain", "Recording failed");
  }
}

void handleRecordStop() {

  if (!recording) {
    server.send(200, "text/plain", "Not recording");
    return;
  }

  stopRecording();

  server.send(200, "text/plain", "Video saved successfully");
}

// =================================================
// SAFE FILE PATH CHECK
// =================================================

bool validMediaPath(String path) {

  if (
    !path.startsWith("/photos/") &&
    !path.startsWith("/videos/")
  ) {
    return false;
  }

  if (
    path.indexOf("..") >= 0 ||
    path.indexOf('\\') >= 0
  ) {
    return false;
  }

  return true;
}

// =================================================
// VIEW / DOWNLOAD FILE
// =================================================

void handleFile() {

  String path = server.arg("name");

  if (!validMediaPath(path)) {
    server.send(400, "text/plain", "Invalid file path");
    return;
  }

  if (recording && path == currentVideoPath) {
    server.send(409, "text/plain", "Video is still recording");
    return;
  }

  if (!SD_MMC.exists(path)) {
    server.send(404, "text/plain", "File not found");
    return;
  }

  File file = SD_MMC.open(path, FILE_READ);

  if (!file) {
    server.send(500, "text/plain", "Cannot open file");
    return;
  }

  if (path.endsWith(".avi")) {

    server.sendHeader(
      "Content-Disposition",
      "attachment; filename=\"" +
      path.substring(path.lastIndexOf('/') + 1) + "\""
    );

    server.streamFile(file, "application/octet-stream");

  } else {

    server.streamFile(file, "image/jpeg");
  }

  file.close();
}

// =================================================
// DELETE SINGLE FILE
// =================================================

void handleDelete() {

  String path = server.arg("name");

  if (!validMediaPath(path)) {
    server.send(400, "text/plain", "Invalid path");
    return;
  }

  if (recording && path == currentVideoPath) {
    server.send(409, "text/plain", "Cannot delete active recording");
    return;
  }

  if (!SD_MMC.exists(path)) {
    server.send(404, "text/plain", "File not found");
    return;
  }

  if (SD_MMC.remove(path)) {

    Serial.print("DELETED: ");
    Serial.println(path);

    server.send(200, "text/plain", "File deleted");

  } else {

    server.send(500, "text/plain", "Delete failed");
  }
}

// =================================================
// COUNT FILES
// =================================================

uint32_t countFiles(const char *directory) {

  File dir = SD_MMC.open(directory);

  if (!dir || !dir.isDirectory()) {
    return 0;
  }

  uint32_t count = 0;

  File file = dir.openNextFile();

  while (file) {

    if (!file.isDirectory()) {
      count++;
    }

    file.close();
    file = dir.openNextFile();
  }

  dir.close();

  return count;
}

// =================================================
// GALLERY API
// =================================================

void appendDirectoryJSON(
  const char *directory,
  const char *type,
  String &json,
  bool &first
) {

  File dir = SD_MMC.open(directory);

  if (!dir || !dir.isDirectory()) {
    return;
  }

  File file = dir.openNextFile();

  while (file) {

    if (!file.isDirectory()) {

      String name = file.name();

      if (!name.startsWith("/")) {
        name = String(directory) + "/" + name;
      }

      if (!first) {
        json += ",";
      }

      first = false;

      json += "{\"name\":\"";
      json += name;
      json += "\",\"type\":\"";
      json += type;
      json += "\",\"size\":";
      json += String(file.size());
      json += "}";
    }

    file.close();
    file = dir.openNextFile();
  }

  dir.close();
}

void handleGallery() {

  String json = "[";
  bool first = true;

  appendDirectoryJSON(
    "/photos", "photo", json, first
  );

  appendDirectoryJSON(
    "/videos", "video", json, first
  );

  json += "]";

  server.send(200, "application/json", json);
}

// =================================================
// STORAGE INFORMATION
// =================================================

void handleStorage() {

  if (!sdReady) {
    server.send(503, "application/json",
                "{\"error\":\"SD card unavailable\"}");
    return;
  }

  uint32_t totalMB =
    (uint32_t)(SD_MMC.totalBytes() / 1048576ULL);

  uint32_t usedMB =
    (uint32_t)(SD_MMC.usedBytes() / 1048576ULL);

  uint32_t freeMB =
    totalMB > usedMB ? totalMB - usedMB : 0;

  String json = "{";

  json += "\"totalMB\":" + String(totalMB) + ",";
  json += "\"usedMB\":" + String(usedMB) + ",";
  json += "\"freeMB\":" + String(freeMB) + ",";

  json += "\"photos\":" +
          String(countFiles("/photos")) + ",";

  json += "\"videos\":" +
          String(countFiles("/videos")) + ",";

  json += "\"recording\":";
  json += recording ? "true" : "false";

  json += "}";

  server.send(200, "application/json", json);
}

// =================================================
// DELETE ALL MEDIA
// =================================================

void deleteDirectoryFiles(const char *directory) {

  File dir = SD_MMC.open(directory);

  if (!dir || !dir.isDirectory()) {
    return;
  }

  File file = dir.openNextFile();

  while (file) {

    String name = file.name();

    if (!name.startsWith("/")) {
      name = String(directory) + "/" + name;
    }

    bool isDirectory = file.isDirectory();

    file.close();

    if (!isDirectory) {

      if (!(recording && name == currentVideoPath)) {
        SD_MMC.remove(name);
      }
    }

    file = dir.openNextFile();
  }

  dir.close();
}

void handleDeleteAll() {

  if (recording) {
    server.send(
      409,
      "text/plain",
      "Stop recording before deleting all files"
    );
    return;
  }

  deleteDirectoryFiles("/photos");
  deleteDirectoryFiles("/videos");

  server.send(200, "text/plain", "All media deleted");
}

// =================================================
// CAMERA WEB INTERFACE
// =================================================

void handleRoot() {

  String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>ESP32 Camera Pro</title>

<style>

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  padding: 15px;
  background: #101419;
  color: white;
  font-family: Arial, sans-serif;
}

.header {
  text-align: center;
  color: #00d084;
  font-size: 24px;
  font-weight: bold;
  margin: 15px;
}

.status {
  text-align: center;
  color: #aaa;
  margin-bottom: 15px;
}

.camera {
  width: 100%;
  max-width: 800px;
  display: block;
  margin: auto;
  border-radius: 12px;
  background: #000;
  border: 2px solid #333;
}

.controls {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin-top: 18px;
}

button {
  padding: 16px 8px;
  border: none;
  border-radius: 10px;
  color: white;
  font-size: 15px;
  font-weight: bold;
  cursor: pointer;
}

.photo {
  background: #087f50;
}

.record {
  background: #c62828;
}

.stop {
  background: #555;
}

.refresh {
  background: #1769aa;
}

.deleteall {
  background: #9c2424;
}

.card {
  background: #1c242d;
  border-radius: 12px;
  padding: 15px;
  margin-top: 18px;
}

.card h3 {
  color: #00d084;
  margin-top: 0;
}

.memory {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}

.memory div {
  background: #29333e;
  padding: 12px;
  border-radius: 8px;
}

.value {
  display: block;
  font-size: 22px;
  font-weight: bold;
  margin-top: 6px;
}

.item {
  background: #29333e;
  padding: 10px;
  border-radius: 8px;
  margin: 10px 0;
  overflow-wrap: anywhere;
}

.item img {
  width: 100%;
  border-radius: 8px;
  margin-bottom: 8px;
}

.item button {
  padding: 9px 14px;
  margin: 5px 5px 0 0;
  font-size: 13px;
}

.download {
  background: #1769aa;
}

.remove {
  background: #c62828;
}

a {
  color: white;
  text-decoration: none;
}

#message {
  text-align: center;
  color: #00d084;
  padding: 10px;
  overflow-wrap: anywhere;
}

</style>

</head>

<body>

<div class="header">ESP32 CAMERA PRO</div>

<div class="status" id="status">
  CAMERA READY
</div>

<img id="preview" class="camera" src="/preview">

<div class="controls">

  <button class="photo" onclick="takePhoto()">
    📸 CLICK PHOTO
  </button>

  <button class="record" id="recordBtn" onclick="startRecord()">
    🔴 START RECORDING
  </button>

  <button class="stop" onclick="stopRecord()">
    ⏹ STOP RECORDING
  </button>

  <button class="refresh" onclick="refreshAll()">
    🔄 REFRESH GALLERY
  </button>

</div>

<div id="message"></div>

<div class="card">

  <h3>💾 SD CARD MEMORY</h3>

  <div class="memory">

    <div>
      Total
      <span class="value" id="total">--</span>
    </div>

    <div>
      Used
      <span class="value" id="used">--</span>
    </div>

    <div>
      Free
      <span class="value" id="free">--</span>
    </div>

    <div>
      Photos
      <span class="value" id="photos">0</span>
    </div>

    <div>
      Videos
      <span class="value" id="videos">0</span>
    </div>

    <div>
      Recording
      <span class="value" id="recStatus">NO</span>
    </div>

  </div>

</div>

<div class="card">

  <h3>🖼 PHOTO & VIDEO GALLERY</h3>

  <div id="gallery">
    Loading gallery...
  </div>

  <button class="deleteall" onclick="deleteAll()">
    🗑 DELETE ALL MEDIA
  </button>

</div>

<script>

const message = document.getElementById("message");

async function request(url) {

  const response = await fetch(url);

  const text = await response.text();

  if (!response.ok) {
    throw new Error(text);
  }

  return text;
}

async function takePhoto() {

  try {

    message.innerText = "Capturing photo...";

    const result = await request("/api/photo");

    message.innerText = result;

    refreshAll();

  } catch(e) {

    message.innerText = "Error: " + e.message;
  }
}

async function startRecord() {

  try {

    const result = await request("/api/record/start");

    message.innerText = result;

    refreshAll();

  } catch(e) {

    message.innerText = "Error: " + e.message;
  }
}

async function stopRecord() {

  try {

    const result = await request("/api/record/stop");

    message.innerText = result;

    refreshAll();

  } catch(e) {

    message.innerText = "Error: " + e.message;
  }
}

async function loadMemory() {

  const response = await fetch("/api/storage");

  const data = await response.json();

  if(data.error) throw new Error(data.error);

  document.getElementById("total").innerText =
    data.totalMB + " MB";

  document.getElementById("used").innerText =
    data.usedMB + " MB";

  document.getElementById("free").innerText =
    data.freeMB + " MB";

  document.getElementById("photos").innerText =
    data.photos;

  document.getElementById("videos").innerText =
    data.videos;

  document.getElementById("recStatus").innerText =
    data.recording ? "YES" : "NO";

  document.getElementById("recordBtn").innerText =
    data.recording ? "🔴 RECORDING..." : "🔴 START RECORDING";

  document.getElementById("status").innerText =
    data.recording ? "VIDEO RECORDING ACTIVE" : "CAMERA READY";
}

async function loadGallery() {

  const response = await fetch("/api/files");

  const files = await response.json();

  const gallery = document.getElementById("gallery");

  gallery.innerHTML = "";

  if(files.length === 0) {

    gallery.innerHTML = "No photos or videos saved yet.";

    return;
  }

  files.reverse();

  files.forEach(file => {

    const item = document.createElement("div");

    item.className = "item";

    const name = document.createElement("div");

    name.innerText = file.name;

    item.appendChild(name);

    const size = document.createElement("div");

    size.innerText =
      (file.size / 1024).toFixed(1) + " KB";

    item.appendChild(size);

    const url =
      "/file?name=" + encodeURIComponent(file.name);

    if(file.type === "photo") {

      const img = document.createElement("img");

      img.src = url;

      img.loading = "lazy";

      item.appendChild(img);

    } else {

      const video = document.createElement("div");

      video.innerText = "🎬 VIDEO FILE (AVI)";

      item.appendChild(video);
    }

    const download = document.createElement("a");

    download.href = url;
    download.download = file.name.split("/").pop();

    const downloadBtn = document.createElement("button");

    downloadBtn.className = "download";
    downloadBtn.innerText = "⬇ DOWNLOAD";

    download.appendChild(downloadBtn);

    item.appendChild(download);

    const del = document.createElement("button");

    del.className = "remove";
    del.innerText = "🗑 DELETE";

    del.onclick = async () => {

      if(!confirm("Delete this file?")) return;

      try {

        await request(
          "/api/delete?name=" +
          encodeURIComponent(file.name)
        );

        refreshAll();

      } catch(e) {

        message.innerText = "Error: " + e.message;
      }
    };

    item.appendChild(del);

    gallery.appendChild(item);
  });
}

async function deleteAll() {

  if(!confirm("Delete ALL photos and videos?")) return;

  try {

    const result = await request("/api/delete-all");

    message.innerText = result;

    refreshAll();

  } catch(e) {

    message.innerText = "Error: " + e.message;
  }
}

async function refreshAll() {

  try {

    await loadMemory();

    await loadGallery();

  } catch(e) {

    message.innerText = "Error: " + e.message;
  }
}

// Refresh live preview

setInterval(() => {

  if(!document.hidden) {

    document.getElementById("preview").src =
      "/preview?t=" + Date.now();
  }

}, 500);

// Update memory and gallery

setInterval(refreshAll, 5000);

refreshAll();

</script>

</body>
</html>
)rawliteral";

  server.send(200, "text/html", html);
}

// =================================================
// SETUP CAMERA
// =================================================

bool startCamera() {

  camera_config_t config = {};

  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;

  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;

  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;

  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;

  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;

  config.xclk_freq_hz = 10000000;
  config.pixel_format = PIXFORMAT_JPEG;

  config.frame_size = FRAMESIZE_QVGA;
  config.jpeg_quality = 12;

  if (psramFound()) {

    Serial.println("PSRAM FOUND");

    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.fb_count = 2;
    config.grab_mode = CAMERA_GRAB_LATEST;

  } else {

    Serial.println("PSRAM NOT FOUND");

    config.fb_location = CAMERA_FB_IN_DRAM;
    config.fb_count = 1;
    config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
    config.frame_size = FRAMESIZE_QQVGA;
  }

  esp_err_t err = esp_camera_init(&config);

  if (err != ESP_OK) {

    Serial.printf(
      "Camera initialization failed: 0x%x\n",
      err
    );

    return false;
  }

  sensor_t *sensor = esp_camera_sensor_get();

  if(sensor != NULL) {

    sensor->set_brightness(sensor, 1);
    sensor->set_saturation(sensor, 0);
  }

  Serial.println("Camera initialized!");

  return true;
}

// =================================================
// SETUP SD CARD
// =================================================

bool startSDCard() {

  Serial.println("Initializing SD card...");

  SD_MMC.setPins(
    SD_MMC_CLK,
    SD_MMC_CMD,
    SD_MMC_D0
  );

  if(!SD_MMC.begin("/sdcard", true)) {

    Serial.println("SD card mount failed!");

    return false;
  }

  if(SD_MMC.cardType() == CARD_NONE) {

    Serial.println("No SD card detected!");

    return false;
  }

  if(!SD_MMC.exists("/photos")) {
    SD_MMC.mkdir("/photos");
  }

  if(!SD_MMC.exists("/videos")) {
    SD_MMC.mkdir("/videos");
  }

  Serial.println("SD card ready!");

  Serial.print("Card size: ");
  Serial.print(SD_MMC.cardSize() / (1024 * 1024));
  Serial.println(" MB");

  return true;
}

// =================================================
// START WIFI
// =================================================

void startWiFi() {

  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleep(false);

  WiFi.softAPConfig(
    IPAddress(192, 168, 4, 1),
    IPAddress(192, 168, 4, 1),
    IPAddress(255, 255, 255, 0)
  );

  if(WiFi.softAP(AP_SSID, AP_PASSWORD)) {

    Serial.println("HOTSPOT STARTED");

    Serial.print("AP IP: ");
    Serial.println(WiFi.softAPIP());
  }

  Serial.println("Connecting to Airtel...");

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int timeout = 0;

  while(
    WiFi.status() != WL_CONNECTED &&
    timeout < 30
  ) {

    delay(500);
    Serial.print(".");

    timeout++;
  }

  if(WiFi.status() == WL_CONNECTED) {

    Serial.println("\nAIRTEL CONNECTED");

    Serial.print("Airtel IP: ");
    Serial.println(WiFi.localIP());

  } else {

    Serial.println("\nAirtel connection failed.");
    Serial.println("Hotspot still available.");
  }
}

// =================================================
// SETUP
// =================================================

void setup() {

  Serial.begin(115200);

  delay(1000);

  Serial.println();
  Serial.println("================================");
  Serial.println("FREENOVE ESP32-S3 CAMERA PRO");
  Serial.println("================================");

  cameraReady = startCamera();

  if(!cameraReady) {

    Serial.println("CAMERA ERROR!");
    return;
  }

  sdReady = startSDCard();

  if(!sdReady) {

    Serial.println("SD CARD ERROR!");
    Serial.println("Check card and SD pins.");
  }

  startWiFi();

  // WEB ROUTES

  server.on("/", HTTP_GET, handleRoot);

  server.on("/preview", HTTP_GET, handlePreview);

  server.on("/api/photo", HTTP_GET, handlePhoto);

  server.on("/api/record/start", HTTP_GET, handleRecordStart);

  server.on("/api/record/stop", HTTP_GET, handleRecordStop);

  server.on("/api/files", HTTP_GET, handleGallery);

  server.on("/api/storage", HTTP_GET, handleStorage);

  server.on("/file", HTTP_GET, handleFile);

  server.on("/api/delete", HTTP_GET, handleDelete);

  server.on("/api/delete-all", HTTP_GET, handleDeleteAll);

  server.begin();

  Serial.println();
  Serial.println("================================");
  Serial.println("CAMERA PRO READY");

  Serial.println("AP URL:");
  Serial.println("http://192.168.4.1");

  if(WiFi.status() == WL_CONNECTED) {

    Serial.print("AIRTEL URL: http://");
    Serial.println(WiFi.localIP());
  }

  Serial.println("================================");
}

// =================================================
// MAIN LOOP
// =================================================

void loop() {

  server.handleClient();

  // RECORD VIDEO FRAMES

  if(recording) {

    camera_fb_t *fb = esp_camera_fb_get();

    if(fb) {

      writeAviFrame(fb);

      esp_camera_fb_return(fb);

    } else {

      Serial.println("Frame capture failed");
    }

    delay(100);
  }

  delay(2);
}
